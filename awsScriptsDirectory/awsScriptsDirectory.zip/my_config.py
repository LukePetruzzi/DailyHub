
# Make sure this in the .gitignore file so it stays local and nobody can steal my keys
# keep all my keys up in this piece.


# YouTube
youtube_apiKey = 'AIzaSyCpsZiycFfXihQyjASGdDI9x5LLVtQZ1oI'

# SoundCloud
soundcloud_clientId = 'a423ec2a689e2e331ec33018e7525b7e'
soundcloud_clientSecret = '495db879c027b28dae79a61b95e09223'

# NYTimes
nytimes_apiKey = 'bdadd7e2ecaf469a8c2403509eed601b'

# Imgur
imgur_clientId = '61c0e09e11937b2'
imgur_clientSecret = 'a8d719e123be7310c5cfe96747ded14966d7e82f'