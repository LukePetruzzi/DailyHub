import masterDictMaker
import json
import sys
import datetime

def lambda_handler(json_input, context):
    masterDictionary = masterDictMaker.createMasterDict()

    #sys.stdout.write("It's on!!!!!!" + str(masterDictionary))

    print(json.dumps(masterDictionary, indent=4, sort_keys=True))
    print("MASTER DICTIONARY WAS UPDATED AT: " + str(datetime.datetime.now()))
    sys.stdout.flush()

    #now that this works... look up how to send this masterDictionary as JSON into the amazonDB whatever its called

